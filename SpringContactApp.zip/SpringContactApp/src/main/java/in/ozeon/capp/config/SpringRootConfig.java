
package in.ozeon.capp.config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @author Vuk
 */
@Configuration
//@ComponentScan(basePackages = {"in.ozeon"})
public class SpringRootConfig {
    //TODO: Sevices, DAO, DataSource, Email Sender or some busines layer beans    
    
    @Bean
    public BasicDataSource dataSource(){
        BasicDataSource ds = new BasicDataSource();
        ds.setDriverClassName("com.mysql:.jdbc.Driver");
        ds.setUrl("jdbc:myqsql://localhost:3307/capp_db");
        ds.setUsername("vule");
        ds.setPassword("mysql1");
        ds.setMaxTotal(2);
        ds.setInitialSize(1);
        ds.setTestOnBorrow(true);
        ds.setValidationQuery("SELECT 1");
        ds.setDefaultAutoCommit(true);
        return ds; 
    }

}

